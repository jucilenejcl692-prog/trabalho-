export interface Product {
  id: string;
  title: string;
  description: string;
  price: number; // em reais, ex: 2499.90
  image: string;
  category: "pc-gamer" | "pc-escritorio" | "upgrade" | "periferico";
  stock: number;
}
