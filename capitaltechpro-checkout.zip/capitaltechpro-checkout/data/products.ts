import { Product } from "@/types/product";

// TODO: substituir por dados vindos de um banco (Postgres, Supabase, etc.)
// Por enquanto, um catálogo estático pra você já testar o fluxo de pagamento.
export const products: Product[] = [
  {
    id: "pc-gamer-i5-rtx4060",
    title: "PC Gamer i5 12400F + RTX 4060",
    description:
      "Intel Core i5-12400F, RTX 4060 8GB, 16GB RAM DDR4, SSD 500GB NVMe, fonte 600W 80 Plus.",
    price: 4899.9,
    image: "/produtos/pc-gamer-i5.jpg",
    category: "pc-gamer",
    stock: 5,
  },
  {
    id: "pc-escritorio-i3",
    title: "PC Escritório i3 + 8GB RAM",
    description:
      "Intel Core i3-12100, 8GB RAM DDR4, SSD 240GB, ideal para trabalho e estudos.",
    price: 1899.9,
    image: "/produtos/pc-escritorio-i3.jpg",
    category: "pc-escritorio",
    stock: 8,
  },
  {
    id: "upgrade-ssd-1tb",
    title: "Upgrade SSD NVMe 1TB (instalado)",
    description: "SSD NVMe 1TB com instalação e migração de sistema inclusas.",
    price: 449.9,
    image: "/produtos/ssd-1tb.jpg",
    category: "upgrade",
    stock: 20,
  },
];

export function getProductById(id: string): Product | undefined {
  return products.find((p) => p.id === id);
}
