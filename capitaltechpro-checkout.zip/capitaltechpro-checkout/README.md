# Checkout Capital Tech Pro — Mercado Pago

Pacote de arquivos para adicionar **pagamento real com parcelamento** ao seu
site Next.js da Capital Tech Pro, usando o Mercado Pago (Checkout Pro).

## Como funciona

1. Cliente entra em `/produtos`, escolhe um PC e clica em "Comprar agora".
2. O botão chama `POST /api/checkout`, que cria uma "preferência" de
   pagamento no Mercado Pago e devolve um link de checkout.
3. Cliente é redirecionado para a página segura do Mercado Pago, escolhe
   cartão/pix/boleto e **as parcelas** (o parcelamento é nativo do MP —
   você não precisa programar isso).
4. Após pagar, o cliente volta para `/pedido/sucesso`, `/erro` ou
   `/pendente`.
5. Em paralelo, o Mercado Pago chama `/api/webhook` automaticamente
   confirmando o pagamento — é ali que você deve dar baixa no estoque,
   marcar o pedido como pago, etc.

## Passo a passo para colocar no ar

### 1. Copiar os arquivos

Copie as pastas `app/`, `components/`, `data/`, `lib/`, `types/` deste
pacote para dentro do seu projeto Next.js existente da Capital Tech Pro,
mesclando com o que já existe (não sobrescreva suas páginas atuais).

### 2. Instalar o SDK do Mercado Pago

```bash
npm install mercadopago
```

### 3. Criar conta e pegar as credenciais

1. Crie/acesse sua conta em https://www.mercadopago.com.br
2. Vá em **Seu negócio > Configurações > Credenciais** (ou
   developers.mercadopago.com.br/panel/app)
3. Copie o **Access Token de teste** primeiro para testar tudo
4. Copie `.env.local.example` para `.env.local` e cole o token

### 4. Configurar parcelamento

O número máximo de parcelas e se terá juros é configurado direto no
painel do Mercado Pago, em **Configurações > Parcelamento** (ou
"Taxas e parcelas"). O código já está preparado para até 12x
(`installments: 12`), mas quem define o real limite disponível pro
cliente é o painel da sua conta.

### 5. Testar pagamento (modo sandbox)

Com o Access Token de TESTE, use os cartões de teste do Mercado Pago
para simular aprovação/recusa:
https://www.mercadopago.com.br/developers/pt/docs/checkout-pro/additional-content/test-cards

### 6. Ir para produção

1. Troque `MP_ACCESS_TOKEN` pelo token de produção (`APP_USR-...`)
2. Atualize `NEXT_PUBLIC_SITE_URL` para o domínio real (ex:
   `https://capitaltechpro.com.br`)
3. Configure a `notification_url` (webhook) também no painel do MP,
   como redundância

## Próximos passos importantes (ainda não incluídos aqui)

- **Banco de dados de pedidos**: hoje o "pedido" só existe como um ID
  gerado na hora. Para controle real de vendas, estoque e histórico,
  recomendo Postgres via Supabase ou Neon (posso montar isso também).
- **Notificação automática**: enviar WhatsApp/e-mail para você e para
  o cliente quando o webhook confirmar o pagamento.
- **Fotos reais dos produtos** em vez dos placeholders em
  `data/products.ts`.
- **Painel admin** simples para você cadastrar produtos sem mexer no
  código.

Qualquer uma dessas partes eu monto na sequência, é só pedir.
