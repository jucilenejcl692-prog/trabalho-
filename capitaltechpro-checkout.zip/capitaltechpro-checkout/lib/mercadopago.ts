import { MercadoPagoConfig, Preference, Payment } from "mercadopago";

if (!process.env.MP_ACCESS_TOKEN) {
  throw new Error(
    "MP_ACCESS_TOKEN não configurado. Adicione no .env.local (veja .env.local.example)."
  );
}

// Access Token de PRODUÇÃO ou TESTE, gerado no painel do Mercado Pago:
// https://www.mercadopago.com.br/developers/panel/app
export const mpClient = new MercadoPagoConfig({
  accessToken: process.env.MP_ACCESS_TOKEN,
  options: { timeout: 8000 },
});

export const mpPreference = new Preference(mpClient);
export const mpPayment = new Payment(mpClient);
