"use client";

import { useState } from "react";

interface CheckoutButtonProps {
  productId: string;
  quantity?: number;
}

export default function CheckoutButton({
  productId,
  quantity = 1,
}: CheckoutButtonProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleClick() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productId, quantity }),
      });
      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Erro ao iniciar pagamento.");
      }

      // Redireciona o cliente pro checkout hospedado do Mercado Pago
      window.location.href = data.init_point;
    } catch (err: any) {
      setError(err.message || "Erro inesperado.");
      setLoading(false);
    }
  }

  return (
    <div>
      <button
        onClick={handleClick}
        disabled={loading}
        className="w-full rounded-lg bg-blue-600 px-6 py-3 font-semibold text-white transition hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-60"
      >
        {loading ? "Redirecionando..." : "Comprar agora"}
      </button>
      {error && <p className="mt-2 text-sm text-red-500">{error}</p>}
    </div>
  );
}
