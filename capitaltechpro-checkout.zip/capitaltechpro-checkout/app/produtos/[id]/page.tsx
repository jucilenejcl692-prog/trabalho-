import { notFound } from "next/navigation";
import { getProductById, products } from "@/data/products";
import CheckoutButton from "@/components/CheckoutButton";

export function generateStaticParams() {
  return products.map((p) => ({ id: p.id }));
}

export default function ProdutoPage({ params }: { params: { id: string } }) {
  const product = getProductById(params.id);
  if (!product) return notFound();

  return (
    <main className="mx-auto max-w-3xl px-6 py-16">
      <h1 className="text-3xl font-bold text-white">{product.title}</h1>
      <p className="mt-4 text-gray-400">{product.description}</p>
      <p className="mt-6 text-3xl font-bold text-blue-500">
        R$ {product.price.toFixed(2)}
      </p>
      <p className="text-sm text-gray-500">
        Parcele em até 12x no cartão de crédito
      </p>

      <div className="mt-8 max-w-xs">
        <CheckoutButton productId={product.id} />
      </div>
    </main>
  );
}
