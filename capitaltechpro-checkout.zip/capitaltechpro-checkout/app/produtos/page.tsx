import Link from "next/link";
import { products } from "@/data/products";

export default function ProdutosPage() {
  return (
    <main className="mx-auto max-w-6xl px-6 py-16">
      <h1 className="mb-10 text-3xl font-bold text-white">
        Nossos Computadores
      </h1>
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {products.map((product) => (
          <Link
            key={product.id}
            href={`/produtos/${product.id}`}
            className="rounded-xl border border-gray-800 bg-gray-900 p-5 transition hover:border-blue-600"
          >
            <h2 className="text-lg font-semibold text-white">
              {product.title}
            </h2>
            <p className="mt-2 text-sm text-gray-400">
              {product.description}
            </p>
            <p className="mt-4 text-xl font-bold text-blue-500">
              R$ {product.price.toFixed(2)}
            </p>
            <p className="text-xs text-gray-500">em até 12x no cartão</p>
          </Link>
        ))}
      </div>
    </main>
  );
}
