import { NextRequest, NextResponse } from "next/server";
import { mpPreference } from "@/lib/mercadopago";
import { getProductById } from "@/data/products";

// URL pública do seu site (produção). Configure em .env.local
const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";

export async function POST(req: NextRequest) {
  try {
    const { productId, quantity } = await req.json();

    if (!productId || !quantity || quantity < 1) {
      return NextResponse.json(
        { error: "productId e quantity são obrigatórios." },
        { status: 400 }
      );
    }

    const product = getProductById(productId);
    if (!product) {
      return NextResponse.json(
        { error: "Produto não encontrado." },
        { status: 404 }
      );
    }
    if (product.stock < quantity) {
      return NextResponse.json(
        { error: "Estoque insuficiente." },
        { status: 400 }
      );
    }

    // ID interno do pedido — troque por um registro real no seu banco
    // (crie o pedido como "pendente" ANTES de redirecionar o cliente).
    const orderId = `${productId}-${Date.now()}`;

    const preference = await mpPreference.create({
      body: {
        items: [
          {
            id: product.id,
            title: product.title,
            quantity,
            unit_price: product.price,
            currency_id: "BRL",
          },
        ],
        payment_methods: {
          // Deixa o parcelamento liberado (o teto de parcelas é definido
          // nas configurações da sua conta Mercado Pago, normalmente até 12x).
          installments: 12,
          default_installments: 1,
        },
        back_urls: {
          success: `${BASE_URL}/pedido/sucesso`,
          failure: `${BASE_URL}/pedido/erro`,
          pending: `${BASE_URL}/pedido/pendente`,
        },
        auto_return: "approved",
        external_reference: orderId,
        notification_url: `${BASE_URL}/api/webhook`,
      },
    });

    return NextResponse.json({
      init_point: preference.init_point, // URL de checkout para redirecionar o cliente
      orderId,
    });
  } catch (err) {
    console.error("Erro ao criar preferência Mercado Pago:", err);
    return NextResponse.json(
      { error: "Erro ao iniciar pagamento. Tente novamente." },
      { status: 500 }
    );
  }
}
