import { NextRequest, NextResponse } from "next/server";
import { mpPayment } from "@/lib/mercadopago";

// O Mercado Pago chama essa rota automaticamente quando o status
// de um pagamento muda (aprovado, recusado, estornado etc).
// Configure essa URL pública no painel do MP também, como redundância.
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    // Formato padrão de notificação: { type: "payment", data: { id: "..." } }
    if (body.type === "payment") {
      const paymentId = body.data.id;
      const payment = await mpPayment.get({ id: paymentId });

      const status = payment.status; // approved | pending | rejected | ...
      const orderId = payment.external_reference;
      const installments = payment.installments;
      const amount = payment.transaction_amount;

      // TODO: aqui você atualiza o pedido no seu banco de dados:
      // - status === "approved"  -> marcar pedido como pago, baixar estoque, enviar e-mail/WhatsApp
      // - status === "rejected"  -> marcar como falho
      // - status === "pending"   -> manter pendente (ex: boleto)
      console.log("Pagamento recebido:", {
        orderId,
        status,
        installments,
        amount,
      });
    }

    // Sempre responda 200 rápido, senão o Mercado Pago tenta reenviar.
    return NextResponse.json({ received: true }, { status: 200 });
  } catch (err) {
    console.error("Erro no webhook Mercado Pago:", err);
    // Ainda assim retorne 200 para não gerar retentativas infinitas
    // enquanto você debuga — ajuste isso quando o banco estiver plugado.
    return NextResponse.json({ received: true }, { status: 200 });
  }
}
