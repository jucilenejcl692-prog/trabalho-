import Link from "next/link";

export default function SucessoPage() {
  return (
    <main className="mx-auto flex max-w-xl flex-col items-center px-6 py-24 text-center">
      <h1 className="text-3xl font-bold text-green-500">
        Pagamento aprovado! 🎉
      </h1>
      <p className="mt-4 text-gray-400">
        Seu pedido na Capital Tech Pro foi confirmado. Em breve entraremos em
        contato pelo WhatsApp com os próximos passos.
      </p>
      <Link
        href="/"
        className="mt-8 rounded-lg bg-blue-600 px-6 py-3 font-semibold text-white hover:bg-blue-700"
      >
        Voltar ao site
      </Link>
    </main>
  );
}
