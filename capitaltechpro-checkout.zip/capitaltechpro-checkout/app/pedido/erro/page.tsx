import Link from "next/link";

export default function ErroPage() {
  return (
    <main className="mx-auto flex max-w-xl flex-col items-center px-6 py-24 text-center">
      <h1 className="text-3xl font-bold text-red-500">
        Não foi possível concluir o pagamento
      </h1>
      <p className="mt-4 text-gray-400">
        O pagamento foi recusado ou cancelado. Nenhuma cobrança foi feita.
        Tente novamente ou fale com a gente pelo WhatsApp.
      </p>
      <Link
        href="/produtos"
        className="mt-8 rounded-lg bg-blue-600 px-6 py-3 font-semibold text-white hover:bg-blue-700"
      >
        Tentar novamente
      </Link>
    </main>
  );
}
