import Link from "next/link";

export default function PendentePage() {
  return (
    <main className="mx-auto flex max-w-xl flex-col items-center px-6 py-24 text-center">
      <h1 className="text-3xl font-bold text-yellow-500">
        Pagamento em análise
      </h1>
      <p className="mt-4 text-gray-400">
        Recebemos sua compra e estamos aguardando a confirmação (comum em
        boleto ou análise de cartão). Você receberá a confirmação por
        e-mail/WhatsApp assim que for aprovado.
      </p>
      <Link
        href="/"
        className="mt-8 rounded-lg bg-blue-600 px-6 py-3 font-semibold text-white hover:bg-blue-700"
      >
        Voltar ao site
      </Link>
    </main>
  );
}
